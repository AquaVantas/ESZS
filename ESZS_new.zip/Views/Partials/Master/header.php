<meta http-equiv="Content-Type" content="text/html;charset=utf-8">
<link rel="stylesheet" href="Plugins/bootstrap/bootstrap.min.css">
<link rel="stylesheet" href="Style/Master.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.css"/>
<script src="Plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<script type="text/javascript" src="Scripts/Main.js"></script>