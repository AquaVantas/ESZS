﻿<?php
	$dir = "/xampp/htdocs/ESZS_new/Content/WebsiteContent";					
	$files1 = scandir($dir);
	$fileDirectories = array($dir);
	checkAllFolders($fileDirectories, $dir);

	function checkAllFolders(&$fileDirectories, $dir) {
		$directory = scandir($dir);
		foreach($directory as $files) {
			if(is_dir($dir . "/" . $files) && ($files != "." && $files != "..")) {
				$dirA = $dir . "/" . $files;
				array_push($fileDirectories, $dirA);
				checkAllFolders($fileDirectories, $dirA);
			}
		}
	}
?>
<div class="content-sidebar-wrapper" lookingForContent="">
	<div class="container">
		<span><?php print_r($fileDirectories) ?></span><br>
		<span><?php print_r(count($fileDirectories)) ?></span>
		<span><?php print_r($files1) ?></span>
	</div>
</div>